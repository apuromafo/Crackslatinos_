


struct __MajorFunction
{
  void *_MJ_CREATE;
  void *_MJ_CREATE_NAMED_PIPE;
  void *_MJ_CLOSE;
  void *_MJ_READ;
  void *_MJ_WRITE;
  void *_MJ_QUERY_INFORMATION;
  void *_MJ_SET_INFORMATION;
  void *_MJ_QUERY_EA;
  void *_MJ_SET_EA;
  void *_MJ_FLUSH_BUFFERS;
  void *_MJ_QUERY_VOLUME_INFORMATION;
  void *_MJ_SET_VOLUME_INFORMATION;
  void *_MJ_DIRECTORY_CONTROL;
  void *_MJ_FILE_SYSTEM_CONTROL;
  void *_MJ_DEVICE_CONTROL;
  void *_MJ_INTERNAL_DEVICE_CONTROL;
  void *_MJ_SCSI;
  void *_MJ_SHUTDOWN;
  void *_MJ_LOCK_CONTROL;
  void *_MJ_CLEANUP;
  void *_MJ_CREATE_MAILSLOT;
  void *_MJ_QUERY_SECURITY;
  void *_MJ_SET_SECURITY;
  void *_MJ_POWER;
  void *_MJ_SYSTEM_CONTROL;
  void *_MJ_DEVICE_CHANGE;
  void *_MJ_QUERY_QUOTA;
  void *_MJ_SET_QUOTA;
  void *_MJ_PNP;
  void *_MJ_PNP_POWER;
  void *_MJ_MAXIMUM_FUNCTION;
};


struct _DRIVER_OBJECT
{
  __int16 Type;
  __int16 Size;
  _DEVICE_OBJECT *DeviceObject;
  unsigned int Flags;
  void *DriverStart;
  unsigned int DriverSize;
  void *DriverSection;
  _DRIVER_EXTENSION *DriverExtension;
  _UNICODE_STRING DriverName;
  _UNICODE_STRING *HardwareDatabase;
  _FAST_IO_DISPATCH *FastIoDispatch;
  int (__fastcall *DriverInit)(_DRIVER_OBJECT *, _UNICODE_STRING *);
  void (__fastcall *DriverStartIo)(_DEVICE_OBJECT *, _IRP *);
  void (__fastcall *DriverUnload)(_DRIVER_OBJECT *);
  __MajorFunction MajorFunction;
};